# YouTimer
YouTimer is a Google Extension that shows you how much time YOU spend on each website, for the purposes of reminding you of your time commitments on the web.
